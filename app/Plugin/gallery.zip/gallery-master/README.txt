﻿Description

This Gallery plugin for Croogo can create albums and upload photos

Instalation

	1. Upload plugin
	2. Add a new album
	3. Upload photos
	4. Enjoy :)
	
Create album and upload any photos, you can access the albums in http://yoursitewithcroogo/gallery, or include it in any location of its nodes how often need,  just put in the body [Gallery: slug_gallery] that the plugin will automatically substitute by your photo album.

Eg.:

[Gallery:my_carnival_brazil_album] 

Author: Edinei L. Cipriani
E-mail: <phpedinei@gmail.com>
Website: http://www.edineicipriani.com.br
