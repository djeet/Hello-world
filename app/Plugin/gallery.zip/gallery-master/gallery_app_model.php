<?php
class GalleryAppModel extends AppModel {

}
?>